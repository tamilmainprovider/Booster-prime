# InstaPrime Android App

WebView Android app for **https://instaprime.shop/**

---

## 📱 Features

- ✅ **Splash Screen** — Animated logo with scale + fade effects
- ✅ **Bottom Navigation** — Orders (left) | Home (center) | About (right)
- ✅ **Payment Gateway Support** — Razorpay, PayU, Cashfree, UPI, PhonePe, GPay, Paytm
- ✅ **Back Button Logic** — Navigates WebView history, never exits the app
- ✅ **Session Cookies** — Third-party cookies enabled for cart/auth
- ✅ **File Upload** — Camera & gallery access for profile/product images
- ✅ **Offline Error Page** — Friendly error with Retry button
- ✅ **Android 10+** (API 29+) support
- ✅ **Hardware Accelerated** rendering

---

## 🔗 URLs

| Tab    | URL                                       |
|--------|-------------------------------------------|
| Orders | https://instaprime.shop/mobile/orders     |
| Home   | https://instaprime.shop/                  |
| About  | https://instaprime.shop/mobile/about      |

---

## 🛠️ Build Requirements

- **Android Studio** Hedgehog (2023.1.1) or newer — [Download](https://developer.android.com/studio)
- **JDK 17** (bundled with Android Studio)
- **Android SDK** API 34 + API 29

---

## 🚀 Build Steps (Android Studio)

### Step 1 — Open Project
1. Open Android Studio
2. Click **File → Open**
3. Select the `InstaPrime` folder (this folder)
4. Wait for Gradle sync to complete

### Step 2 — Sync & Build
1. If prompted, click **Sync Now**
2. Wait for dependencies to download (~2-3 minutes first time)

### Step 3 — Generate Debug APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Step 4 — Generate Release APK
1. `Build → Generate Signed Bundle / APK`
2. Choose **APK**
3. Create or select a keystore:
   - Click **Create new...**
   - Fill in keystore path, password, alias, key details
4. Select **release** build variant
5. Click **Finish**

APK location: `app/build/outputs/apk/release/app-release.apk`

### Step 5 — Generate AAB (for Play Store)
1. `Build → Generate Signed Bundle / APK`
2. Choose **Android App Bundle**
3. Use same keystore as Step 4
4. Click **Finish**

AAB location: `app/build/outputs/bundle/release/app-release.aab`

---

## 📦 Build via Command Line

```bash
# Debug APK
./gradlew assembleDebug

# Release APK (needs keystore configured in build.gradle)
./gradlew assembleRelease

# AAB Bundle
./gradlew bundleRelease
```

---

## 🔑 Keystore (Release Builds)

For release builds, add to `app/build.gradle` inside `android {}`:

```groovy
signingConfigs {
    release {
        storeFile file("your-keystore.jks")
        storePassword "your-store-password"
        keyAlias "your-key-alias"
        keyPassword "your-key-password"
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false
    }
}
```

> ⚠️ Never commit keystore files or passwords to version control.

---

## 💳 Payment Gateway Notes

The app is configured to allow these payment domains without leaving the WebView:
- `razorpay.com`
- `payu.in`
- `cashfree.com`
- `stripe.com`
- `payumoney.com`
- `ccavenue.com`

UPI deep links (`upi://`, `phonepe://`, `gpay://`, `paytm://`) open the installed payment apps automatically.

---

## 📂 Project Structure

```
InstaPrime/
├── app/
│   ├── src/main/
│   │   ├── java/com/instaprime/shop/
│   │   │   ├── SplashActivity.java    ← Animated splash screen
│   │   │   └── MainActivity.java      ← WebView + bottom nav
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_splash.xml
│   │   │   │   └── activity_main.xml
│   │   │   ├── menu/
│   │   │   │   └── bottom_nav_menu.xml
│   │   │   ├── drawable/              ← Icons + backgrounds
│   │   │   ├── values/                ← Colors, strings, themes
│   │   │   └── anim/                  ← Transition animations
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🔧 Customization

### Change Brand Color
Edit `app/src/main/res/values/colors.xml`:
```xml
<color name="colorPrimary">#E63946</color>  <!-- Change this -->
```

### Add More Navigation Items
Edit `res/menu/bottom_nav_menu.xml` and add cases in `MainActivity.java`

### Change WebView User Agent
In `MainActivity.java`, find:
```java
settings.setUserAgentString(settings.getUserAgentString() + " InstaPrimeApp/1.0");
```

---

## 📋 Minimum Requirements

| Requirement | Value |
|-------------|-------|
| Android OS | 10.0+ (API 29) |
| Target SDK | 34 (Android 14) |
| Screen | Portrait mode |
| Internet | Required |
