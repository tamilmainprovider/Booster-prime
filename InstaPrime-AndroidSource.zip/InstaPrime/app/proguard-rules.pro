# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep WebView JavaScript interfaces
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep MainActivity and SplashActivity
-keep class com.instaprime.shop.** { *; }

# Payment gateway compatibility
-keep class com.razorpay.** { *; }
-keep class com.payu.** { *; }
-keep class com.cashfree.** { *; }

# Material components
-keep class com.google.android.material.** { *; }
