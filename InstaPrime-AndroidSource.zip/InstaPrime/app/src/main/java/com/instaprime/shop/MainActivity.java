package com.instaprime.shop;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "https://instaprime.shop";
    private static final String HOME_URL = BASE_URL + "/";
    private static final String ORDERS_URL = BASE_URL + "/mobile/orders";
    private static final String ABOUT_URL = BASE_URL + "/mobile/about";

    private WebView webView;
    private ProgressBar progressBar;
    private BottomNavigationView bottomNav;

    private ValueCallback<Uri[]> fileUploadCallback;
    private ActivityResultLauncher<Intent> fileChooserLauncher;

    private int currentNavItem = R.id.nav_home;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress_bar);
        bottomNav = findViewById(R.id.bottom_navigation);

        setupFileChooser();
        setupWebView();
        setupBottomNavigation();

        // Load home page
        webView.loadUrl(HOME_URL);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();

        // Enable JavaScript (required for payment gateways)
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        // DOM Storage for modern web apps
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Zoom settings
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        // Performance
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Mixed content for payment gateways
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // Viewport
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        // User agent — appear as Android app
        settings.setUserAgentString(settings.getUserAgentString() + " InstaPrimeApp/1.0");

        // Allow file access
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Cookies (critical for payment gateways & sessions)
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        // WebViewClient - handle navigation & back stack
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                // Handle tel: and mailto: links
                if (url.startsWith("tel:") || url.startsWith("mailto:")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                }

                // Handle payment gateway redirects (UPI, PhonePe, GPay, etc.)
                if (url.startsWith("upi://") || url.startsWith("phonepe://") ||
                    url.startsWith("gpay://") || url.startsWith("paytm://") ||
                    url.startsWith("intent://")) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        // App not installed, open Play Store or show toast
                        Toast.makeText(MainActivity.this, "Payment app not found", Toast.LENGTH_SHORT).show();
                        return true;
                    }
                }

                // Stay within instaprime.shop domain
                if (url.contains("instaprime.shop") ||
                    url.contains("razorpay.com") ||
                    url.contains("payu.in") ||
                    url.contains("cashfree.com") ||
                    url.contains("stripe.com") ||
                    url.contains("payumoney.com") ||
                    url.contains("ccavenue.com")) {
                    return false; // Let WebView handle it
                }

                // Open external URLs in browser
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(0);
                updateBottomNavForUrl(url);
            }

            @Override
            public void onPageFinished(WebView view, String url, Bitmap favicon) {
                super.onPageFinished(view, url, favicon);
                progressBar.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                // Load offline error page
                view.loadUrl("about:blank");
                view.loadData(getErrorPage(), "text/html", "UTF-8");
            }
        });

        // WebChromeClient - file upload & JS dialogs (for payment)
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                              FileChooserParams fileChooserParams) {
                fileUploadCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    fileUploadCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                // Support popup windows (some payment gateways need this)
                WebView newWebView = new WebView(MainActivity.this);
                newWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                        webView.loadUrl(request.getUrl().toString());
                        return true;
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(newWebView);
                resultMsg.sendToTarget();
                return true;
            }
        });

        // Add JavaScript interface for native features
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
    }

    private void setupBottomNavigation() {
        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_orders) {
                if (currentNavItem != R.id.nav_orders) {
                    currentNavItem = R.id.nav_orders;
                    webView.loadUrl(ORDERS_URL);
                }
                return true;
            } else if (itemId == R.id.nav_home) {
                if (currentNavItem != R.id.nav_home) {
                    currentNavItem = R.id.nav_home;
                    webView.loadUrl(HOME_URL);
                }
                return true;
            } else if (itemId == R.id.nav_about) {
                if (currentNavItem != R.id.nav_about) {
                    currentNavItem = R.id.nav_about;
                    webView.loadUrl(ABOUT_URL);
                }
                return true;
            }
            return false;
        });
    }

    private void updateBottomNavForUrl(String url) {
        if (url.contains("/mobile/orders")) {
            bottomNav.setSelectedItemId(R.id.nav_orders);
            currentNavItem = R.id.nav_orders;
        } else if (url.contains("/mobile/about")) {
            bottomNav.setSelectedItemId(R.id.nav_about);
            currentNavItem = R.id.nav_about;
        } else if (url.equals(HOME_URL) || url.equals(BASE_URL) || url.equals(BASE_URL + "/")) {
            bottomNav.setSelectedItemId(R.id.nav_home);
            currentNavItem = R.id.nav_home;
        }
    }

    private void setupFileChooser() {
        fileChooserLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (fileUploadCallback == null) return;
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    String dataString = result.getData().getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                }
                fileUploadCallback.onReceiveValue(results);
                fileUploadCallback = null;
            }
        );
    }

    @Override
    public void onBackPressed() {
        // Only navigate back within WebView history — never exit the app
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            // If on a section page, go to Home instead of exiting
            String currentUrl = webView.getUrl();
            if (currentUrl != null && !currentUrl.equals(HOME_URL) && !currentUrl.equals(BASE_URL)) {
                webView.loadUrl(HOME_URL);
                bottomNav.setSelectedItemId(R.id.nav_home);
                currentNavItem = R.id.nav_home;
            } else {
                // At home root — minimize app instead of closing
                moveTaskToBack(true);
            }
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            onBackPressed();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private String getErrorPage() {
        return "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
               "<style>body{font-family:sans-serif;display:flex;flex-direction:column;align-items:center;" +
               "justify-content:center;height:100vh;margin:0;background:#f8f9fa;color:#333;text-align:center;}" +
               "h2{color:#e63946;}.btn{background:#e63946;color:#fff;border:none;padding:12px 32px;" +
               "border-radius:24px;font-size:16px;cursor:pointer;margin-top:20px;}" +
               "</style></head><body>" +
               "<h2>&#9888; No Connection</h2>" +
               "<p>Please check your internet connection and try again.</p>" +
               "<button class='btn' onclick='window.location.reload()'>Retry</button>" +
               "</body></html>";
    }

    // JavaScript Bridge for native Android features
    private class NativeBridge {
        @JavascriptInterface
        public String getDeviceInfo() {
            return "Android " + android.os.Build.VERSION.RELEASE;
        }

        @JavascriptInterface
        public void showToast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        webView.restoreState(savedInstanceState);
    }
}
