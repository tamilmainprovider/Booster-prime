package com.instaprime.shop;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private ImageView logoImage;
    private TextView taglineText;
    private View progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        logoImage = findViewById(R.id.splash_logo);
        taglineText = findViewById(R.id.splash_tagline);
        progressBar = findViewById(R.id.splash_progress);

        startSplashAnimation();
    }

    private void startSplashAnimation() {
        // Logo scale-in animation
        logoImage.setScaleX(0f);
        logoImage.setScaleY(0f);
        logoImage.setAlpha(0f);

        taglineText.setAlpha(0f);
        taglineText.setTranslationY(40f);

        progressBar.setAlpha(0f);

        // Logo animation
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(logoImage, "scaleX", 0f, 1.1f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(logoImage, "scaleY", 0f, 1.1f, 1f);
        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(logoImage, "alpha", 0f, 1f);

        scaleX.setDuration(700);
        scaleY.setDuration(700);
        fadeIn.setDuration(500);

        scaleX.setInterpolator(new DecelerateInterpolator());
        scaleY.setInterpolator(new DecelerateInterpolator());

        AnimatorSet logoSet = new AnimatorSet();
        logoSet.playTogether(scaleX, scaleY, fadeIn);

        // Tagline animation
        ObjectAnimator taglineFade = ObjectAnimator.ofFloat(taglineText, "alpha", 0f, 1f);
        ObjectAnimator taglineSlide = ObjectAnimator.ofFloat(taglineText, "translationY", 40f, 0f);
        taglineFade.setDuration(500);
        taglineSlide.setDuration(500);

        AnimatorSet taglineSet = new AnimatorSet();
        taglineSet.playTogether(taglineFade, taglineSlide);
        taglineSet.setStartDelay(400);

        // Progress fade
        ObjectAnimator progressFade = ObjectAnimator.ofFloat(progressBar, "alpha", 0f, 1f);
        progressFade.setDuration(400);
        progressFade.setStartDelay(800);

        AnimatorSet fullSet = new AnimatorSet();
        fullSet.playTogether(logoSet, taglineSet, progressFade);

        fullSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                // Wait then launch main
                logoImage.postDelayed(() -> launchMain(), 1200);
            }
        });

        fullSet.start();
    }

    private void launchMain() {
        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);

        // Smooth transition
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        finish();
    }

    @Override
    public void onBackPressed() {
        // Prevent back press on splash
    }
}
